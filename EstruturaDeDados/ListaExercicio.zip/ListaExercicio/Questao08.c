/*

Função: retorna a area de uma esfera
Autor: Antônio lucas Dantas de Abrantes;
Data: 23/03/2023;
Observações: 

*/

#include <stdio.h>
#include <math.h>


double areaEsfera(float raio){
    double pi = 3.14159265;
    double calculo = (4*pi) * pow(raio,2);
}

int main() {
    
    return 0;
}
